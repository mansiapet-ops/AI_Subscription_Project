#include <mpi.h>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm> // For std::inplace_merge

using namespace std;

// Standard swap function
void swap(int* a, int* b) {
    int t = *a;
    *a = *b;
    *b = t;
}

// Partition function for Sequential QuickSort
int partition(vector<int>& arr, int low, int high) {
    int pivot = arr[high]; // Choosing the last element as pivot
    int i = (low - 1);

    for (int j = low; j <= high - 1; j++) {
        if (arr[j] < pivot) {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return (i + 1);
}

// Standard Sequential QuickSort function
void quickSort(vector<int>& arr, int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

int main(int argc, char** argv) {
    int rank, size;
    
    // 1. Initialize MPI Environment
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank); // Get current process ID
    MPI_Comm_size(MPI_COMM_WORLD, &size); // Get total number of processes

    // Define the total dataset size (must be perfectly divisible by number of processes for simplicity)
    const int N = 100000; 
    int chunk_size = N / size;

    vector<int> global_data;
    vector<int> local_data(chunk_size);

    double start_time, end_time;

    // 2. Master Node (Rank 0) generates the dataset
    if (rank == 0) {
        global_data.resize(N);
        srand(time(0));
        for (int i = 0; i < N; i++) {
            global_data[i] = rand() % 100000; // Random integers
        }
        
        cout << "Dataset of size " << N << " generated." << endl;
        cout << "Distributing to " << size << " processes..." << endl;
        
        // Start the MPI timer
        start_time = MPI_Wtime();
    }

    // 3. Domain Decomposition: Scatter the data across all processes
    // MPI_Scatter sends equal chunks of global_data to the local_data of each process
    MPI_Scatter(global_data.data(), chunk_size, MPI_INT, 
                local_data.data(), chunk_size, MPI_INT, 
                0, MPI_COMM_WORLD);

    // 4. Local Computation: Every process sorts its own chunk
    quickSort(local_data, 0, chunk_size - 1);

    // 5. Data Aggregation: Gather all sorted chunks back to the Master Node (Rank 0)
    MPI_Gather(local_data.data(), chunk_size, MPI_INT, 
               global_data.data(), chunk_size, MPI_INT, 
               0, MPI_COMM_WORLD);

    // 6. Final Synchronization (Merging) at Master Node
    if (rank == 0) {
        // At this point, global_data has 'size' number of sorted chunks.
        // We need to merge them sequentially to get the final sorted array.
        int current_sorted_size = chunk_size;
        
        for (int i = 1; i < size; i++) {
            // std::inplace_merge efficiently merges two consecutive sorted ranges
            std::inplace_merge(global_data.begin(), 
                               global_data.begin() + current_sorted_size, 
                               global_data.begin() + current_sorted_size + chunk_size);
            
            current_sorted_size += chunk_size;
        }

        // Stop the MPI timer
        end_time = MPI_Wtime();

        // Output the results
        cout << "Sorting completed successfully." << endl;
        cout << "Parallel Execution Time: " << (end_time - start_time) << " seconds." << endl;
        
        // Optional: Verification step to ensure it is actually sorted
        bool is_sorted = true;
        for (int i = 1; i < N; i++) {
            if (global_data[i - 1] > global_data[i]) {
                is_sorted = false;
                break;
            }
        }
        if(is_sorted) cout << "Array is verified to be correctly sorted!" << endl;
    }

    // 7. Terminate MPI Environment
    MPI_Finalize();
    return 0;
}